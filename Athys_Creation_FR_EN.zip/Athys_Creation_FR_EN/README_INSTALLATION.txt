# Athy’s Création — Déploiement Netlify & IONOS (FR/EN)

Ce dossier est **prêt à être déployé** sur Netlify sans étape de build (React via CDN, Tailwind CDN).

## 🚀 Déploiement Netlify (drag & drop)
1. Allez sur https://app.netlify.com et connectez-vous (gratuit).
2. Cliquez **Add new site → Deploy manually**.
3. Glissez-déposez **le dossier `Athys_Creation_FR_EN`** (ou le ZIP extrait) — Netlify crée une URL publique.
4. Activez **HTTPS** (automatique).

## 🌐 Connecter votre domaine IONOS
1. Dans IONOS, ouvrez **Domaines & SSL → votre domaine → DNS**.
2. Ajoutez :
   - CNAME `www` → votre-sous-domaine-netlify.app
   - A `@` → 75.2.60.5
   - A `@` → 99.83.190.102
3. Dans Netlify, **Domain settings → Add custom domain** → validez.

## 🔐 Sécurité (admin)
- Le panneau **Espace administrateur** envoie des requêtes à `http://localhost:4000`.
- Hébergez votre **serveur Node (server.js)** sur Render.com/Railway et remplacez l’URL dans `useLockApi()` si besoin.

## ✉️ Contact pro
- L’email affiché est **hello@athys.fr**.

## 📦 Contenu
- `index.html` : Site complet bilingue, sans faute, design luxueux.
- Aucune étape `npm install` requise.
